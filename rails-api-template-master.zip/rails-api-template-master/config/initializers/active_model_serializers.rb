# frozen_string_literal: true
# Root keys on json resources
ActiveModelSerializers.config.adapter = :json
