# frozen_string_literal: true
class ApplicationJob; end
# class ApplicationJob < ActiveJob::Base
# end
